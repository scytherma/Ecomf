# EcomFy E-Commerce Course Landing Page

## Overview

EcomFy is a Brazilian e-commerce course landing page application designed to promote and sell online courses focused on selling across major platforms (Shopee, Mercado Livre, Amazon, and TikTok Shop). The application features a modern, conversion-optimized design inspired by high-performing Brazilian course landing pages, with emphasis on social proof, urgency, and clear calls-to-action.

The project is a full-stack TypeScript application built with React on the frontend and Express on the backend, utilizing a modern tech stack focused on rapid development and excellent user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, using Vite as the build tool and development server.

**Routing**: Wouter for lightweight client-side routing.

**UI Component System**: shadcn/ui components built on Radix UI primitives, providing accessible, customizable components with Tailwind CSS styling. The design system follows the "new-york" style variant with custom purple-themed color palette (#A855F7 primary, #9333EA secondary) aligned with Brazilian course landing page aesthetics.

**Styling**: Tailwind CSS with custom configuration including HSL-based color system, custom border radius values, and CSS variables for theming. The design prioritizes bold typography (Inter/Poppins fonts), gradient backgrounds, and responsive layouts (mobile-first approach).

**State Management**: TanStack Query (React Query) for server state management, form state handled by React Hook Form with Zod validation.

**Form Validation**: Zod schemas for runtime validation, integrated with React Hook Form via @hookform/resolvers.

### Backend Architecture

**Framework**: Express.js with TypeScript, following ESM module format.

**API Design**: RESTful API with JSON payloads. Current endpoints focus on contact lead collection (`/api/contact` POST/GET).

**Request Handling**: Custom middleware for request logging, JSON parsing with raw body capture for potential webhook integrations, and error handling with user-friendly error messages.

**Session Management**: Infrastructure includes connect-pg-simple for PostgreSQL session storage (though authentication is not yet fully implemented).

**Development Server**: Custom Vite integration for hot module replacement in development, with production serving of static assets.

### Data Storage

**ORM**: Drizzle ORM configured for PostgreSQL with type-safe database queries and migrations.

**Database Provider**: Configured for Neon serverless PostgreSQL (@neondatabase/serverless).

**Schema Design**: Two primary tables defined:
- `users` table with username/password (authentication placeholder)
- `contact_leads` table for capturing prospect information (name, email, phone, message, timestamp)

**Migration Strategy**: Drizzle Kit for schema migrations with push-based deployment to development databases.

**Development Fallback**: In-memory storage implementation (MemStorage class) allows development without database connectivity, maintaining interface compatibility with database storage.

### Design System

**Color Palette**: Custom purple-focused theme (#A855F7 primary) with dark gray backgrounds, designed for high conversion rates following Brazilian e-commerce course aesthetics.

**Typography Hierarchy**: Bold headings (600-800 weight) in Inter/Poppins, clear size progression (text-5xl to text-7xl for hero, text-4xl to text-5xl for sections).

**Layout System**: Tailwind-based spacing system, max-w-7xl containers, responsive grid patterns (1 column mobile → 2 tablet → 3-4 desktop).

**Page Structure**: Multi-section landing page design (9-11 sections planned) including hero, platform showcase, course objectives, testimonials, pricing, FAQ, and contact forms.

### External Dependencies

**UI Component Libraries**:
- Radix UI primitives for accessible components (accordion, dialog, dropdown, popover, etc.)
- Embla Carousel for interactive content carousels
- cmdk for command palette interfaces
- React Icons (specifically Simple Icons for platform logos: Shopee, Amazon, TikTok)
- Lucide React for general iconography

**Form Management**:
- React Hook Form for form state and validation
- Zod for schema validation
- @hookform/resolvers for integration between the two

**Data Fetching**:
- TanStack Query for server state management
- Custom fetch wrapper with error handling and credential support

**Database & ORM**:
- Drizzle ORM for type-safe database queries
- Neon serverless PostgreSQL driver
- drizzle-zod for generating Zod schemas from database schemas

**Build Tools**:
- Vite for frontend bundling and development server
- esbuild for backend bundling in production
- PostCSS with Tailwind CSS and Autoprefixer

**Development Tools**:
- Replit-specific plugins (@replit/vite-plugin-runtime-error-modal, cartographer, dev-banner)
- tsx for TypeScript execution in development

**Utilities**:
- date-fns for date manipulation
- clsx and tailwind-merge for conditional className composition
- class-variance-authority for component variant management
- nanoid for unique ID generation