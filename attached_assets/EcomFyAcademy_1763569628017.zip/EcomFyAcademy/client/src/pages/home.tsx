import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactLeadSchema, type InsertContactLead } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  CheckCircle2,
  Users,
  TrendingUp,
  Award,
  Zap,
  Target,
  BookOpen,
  Sparkles,
  Gift,
  MessageCircle,
  ShoppingBag,
  Package,
  DollarSign,
  Clock,
  Star,
  Instagram,
  Youtube,
  Facebook,
  ChevronDown,
} from "lucide-react";
import { SiShopee, SiAmazon, SiTiktok } from "react-icons/si";

export default function Home() {
  const { toast } = useToast();

  const form = useForm<InsertContactLead>({
    resolver: zodResolver(insertContactLeadSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  const createContactMutation = useMutation({
    mutationFn: async (data: InsertContactLead) => {
      const res = await apiRequest("POST", "/api/contact", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Mensagem enviada com sucesso!",
        description: "Nossa equipe entrará em contato em breve via WhatsApp.",
        variant: "default",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar mensagem",
        description: error.message || "Por favor, tente novamente ou entre em contato via WhatsApp.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: InsertContactLead) => {
    createContactMutation.mutate(data);
  };

  const scrollToContact = () => {
    document.getElementById("contato")?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToPricing = () => {
    document.getElementById("preco")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-gray-900 text-primary-foreground">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE4YzAtMy4zMTQgMi42ODYtNiA2LTZzNi0yLjY4NiA2LTYtMi42ODYtNi02LTYtNiAyLjY4Ni02IDYiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-20"></div>
        
        <div className="container relative mx-auto px-4 py-24 md:py-32">
          <div className="mx-auto max-w-4xl text-center">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 hover:bg-white/30" data-testid="badge-students">
              <Users className="mr-2 h-4 w-4" />
              Mais de 2.000+ Alunos Ativos
            </Badge>
            
            <h1 className="mb-6 font-heading text-5xl font-bold leading-tight tracking-tight md:text-6xl lg:text-7xl" data-testid="text-hero-title">
              Domine o E-commerce e Venda nas{" "}
              <span className="relative inline-block">
                <span className="relative z-10">4 Maiores Plataformas</span>
                <span className="absolute bottom-2 left-0 h-3 w-full bg-yellow-400/30"></span>
              </span>
            </h1>
            
            <p className="mb-8 text-xl text-primary-foreground/90 md:text-2xl" data-testid="text-hero-subtitle">
              Aprenda do zero ao avançado com os mentores{" "}
              <span className="font-semibold">Diogo e Oliveira</span> a vender na{" "}
              <span className="font-semibold">Shopee, Mercado Livre, Amazon e TikTok Shop</span>
            </p>
            
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button
                size="lg"
                onClick={scrollToPricing}
                className="bg-white text-primary shadow-2xl text-lg px-8 py-6 font-semibold"
                data-testid="button-cta-hero"
              >
                <Zap className="mr-2 h-5 w-5" />
                Garantir Minha Vaga Agora
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={scrollToContact}
                className="border-white/30 bg-white/10 text-white backdrop-blur-sm text-lg px-8 py-6 font-semibold"
                data-testid="button-contact-hero"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Falar no WhatsApp
              </Button>
            </div>

            <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-4">
              <div className="text-center" data-testid="stat-revenue">
                <div className="mb-2 text-3xl font-bold">R$50M+</div>
                <div className="text-sm text-primary-foreground/80">Faturamento dos Alunos</div>
              </div>
              <div className="text-center" data-testid="stat-classes">
                <div className="mb-2 text-3xl font-bold">150+</div>
                <div className="text-sm text-primary-foreground/80">Aulas Práticas</div>
              </div>
              <div className="text-center" data-testid="stat-jobs">
                <div className="mb-2 text-3xl font-bold">500+</div>
                <div className="text-sm text-primary-foreground/80">Empregos Gerados</div>
              </div>
              <div className="text-center" data-testid="stat-online">
                <div className="mb-2 text-3xl font-bold">100%</div>
                <div className="text-sm text-primary-foreground/80">Online</div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
            <path d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="hsl(var(--background))"/>
          </svg>
        </div>
      </section>

      {/* Platform Showcase */}
      <section className="py-20 bg-background" id="plataformas">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-platforms-title">
              Aprenda a Vender nas 4 Maiores Plataformas
            </h2>
            <p className="text-lg text-muted-foreground">
              Domine as estratégias específicas de cada marketplace e maximize seus resultados
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="hover-elevate transition-all duration-300 border-t-4 border-t-primary" data-testid="card-platform-shopee">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-orange-100 dark:bg-orange-900/30">
                  <SiShopee className="h-10 w-10 text-orange-600" />
                </div>
                <CardTitle className="text-2xl">Shopee</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  Estratégias de precificação, otimização de anúncios e técnicas para se destacar na maior plataforma mobile
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300 border-t-4 border-t-primary" data-testid="card-platform-mercadolivre">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-900/30">
                  <ShoppingBag className="h-10 w-10 text-yellow-600" />
                </div>
                <CardTitle className="text-2xl">Mercado Livre</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  Domine o Full, reputação, posicionamento e como vender milhares de produtos por mês
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300 border-t-4 border-t-primary" data-testid="card-platform-amazon">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/30">
                  <SiAmazon className="h-10 w-10 text-blue-600" />
                </div>
                <CardTitle className="text-2xl">Amazon</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  FBA, otimização de listings, keywords e como escalar vendas na maior plataforma do mundo
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300 border-t-4 border-t-primary" data-testid="card-platform-tiktok">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-pink-100 dark:bg-pink-900/30">
                  <SiTiktok className="h-10 w-10 text-pink-600" />
                </div>
                <CardTitle className="text-2xl">TikTok Shop</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  Venda através de vídeos, lives e aproveite o crescimento explosivo da plataforma mais quente do momento
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Course Objective */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
            <div>
              <h2 className="mb-6 font-heading text-4xl font-bold md:text-5xl" data-testid="text-objective-title">
                O Que Você Vai Aprender no EcomFy?
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Um dos maiores desafios de quem quer começar ou evoluir no e-commerce é saber{" "}
                <span className="font-semibold text-foreground">onde, como e o que vender</span>.
              </p>
              <p className="mb-8 text-lg text-muted-foreground">
                O EcomFy foi criado para te guiar do absoluto zero até o nível avançado, com{" "}
                <span className="font-semibold text-foreground">aulas práticas e diretas ao ponto</span>.
              </p>

              <div className="space-y-4">
                {[
                  "Como encontrar produtos vencedores de alta demanda",
                  "Estratégias de precificação para maximizar lucros",
                  "Otimização de anúncios e posicionamento orgânico",
                  "Gestão de estoque e logística inteligente",
                  "Atendimento que fideliza e gera mais vendas",
                  "Escalar de R$1.000 para R$50.000+ por mês",
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3" data-testid={`item-objective-${index}`}>
                    <CheckCircle2 className="h-6 w-6 flex-shrink-0 text-primary mt-0.5" />
                    <span className="text-foreground text-lg">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-purple-600/20 p-8 flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="mx-auto h-32 w-32 text-primary mb-6" />
                  <p className="text-2xl font-bold">
                    Do Zero ao Avançado
                  </p>
                  <p className="text-muted-foreground mt-2">
                    Mesmo sem experiência anterior
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Meet the Mentors */}
      <section className="py-20 bg-background" id="mentores">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-mentors-title">
              Conheça Seus Mentores
            </h2>
            <p className="text-lg text-muted-foreground">
              Especialistas com anos de experiência e milhões em vendas comprovadas
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 max-w-5xl mx-auto">
            <Card className="hover-elevate transition-all duration-300" data-testid="card-mentor-diogo">
              <CardHeader className="text-center">
                <div className="mx-auto mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-gradient-to-br from-primary to-purple-600 text-6xl font-bold text-white">
                  D
                </div>
                <CardTitle className="text-3xl">Diogo</CardTitle>
                <CardDescription className="text-lg">Co-fundador & Especialista em Marketplaces</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6 text-center">
                  Com mais de 5 anos de experiência em e-commerce, Diogo já gerou milhões em vendas através de marketplaces. 
                  Especialista em encontrar produtos vencedores e otimização de anúncios.
                </p>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">R$20M+</div>
                    <div className="text-sm text-muted-foreground">Em Vendas</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">5+ Anos</div>
                    <div className="text-sm text-muted-foreground">Experiência</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-mentor-oliveira">
              <CardHeader className="text-center">
                <div className="mx-auto mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-primary text-6xl font-bold text-white">
                  O
                </div>
                <CardTitle className="text-3xl">Oliveira</CardTitle>
                <CardDescription className="text-lg">Co-fundador & Especialista em Escala</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6 text-center">
                  Oliveira é mestre em escalar operações de e-commerce. Responsável por treinar centenas de alunos que hoje faturam 6 dígitos por mês vendendo online.
                </p>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">R$30M+</div>
                    <div className="text-sm text-muted-foreground">Em Vendas</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">1000+</div>
                    <div className="text-sm text-muted-foreground">Alunos Treinados</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Course Modules */}
      <section className="py-20 bg-muted/30" id="modulos">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-modules-title">
              Módulos do Curso EcomFy
            </h2>
            <p className="text-lg text-muted-foreground">
              Conteúdo completo e estruturado para sua jornada no e-commerce
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Target,
                title: "Fundamentos do E-commerce",
                lessons: "15 aulas",
                description: "Base sólida sobre vendas online, mindset empreendedor e primeiros passos",
              },
              {
                icon: Package,
                title: "Encontrando Produtos Vencedores",
                lessons: "20 aulas",
                description: "Técnicas avançadas de pesquisa e validação de produtos de alta demanda",
              },
              {
                icon: SiShopee,
                title: "Dominando a Shopee",
                lessons: "25 aulas",
                description: "Do cadastro à primeira venda e escala na maior plataforma mobile",
              },
              {
                icon: ShoppingBag,
                title: "Mercado Livre Avançado",
                lessons: "25 aulas",
                description: "Full, reputação, anúncios e como vender milhares por mês",
              },
              {
                icon: SiAmazon,
                title: "Amazon FBA Completo",
                lessons: "30 aulas",
                description: "Venda na maior plataforma do mundo com estoque da Amazon",
              },
              {
                icon: SiTiktok,
                title: "TikTok Shop do Zero",
                lessons: "20 aulas",
                description: "Aproveite o boom da plataforma e venda através de vídeos",
              },
              {
                icon: DollarSign,
                title: "Precificação & Lucro",
                lessons: "12 aulas",
                description: "Estratégias de preço, margens e maximização de lucros",
              },
              {
                icon: TrendingUp,
                title: "Tráfego & Marketing",
                lessons: "18 aulas",
                description: "Anúncios pagos, orgânico e estratégias de crescimento",
              },
              {
                icon: Award,
                title: "Escala & Automação",
                lessons: "15 aulas",
                description: "Sistemas para crescer de forma sustentável e automatizada",
              },
            ].map((module, index) => (
              <Card key={index} className="hover-elevate transition-all duration-300 group" data-testid={`card-module-${index}`}>
                <CardHeader>
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <module.icon className="h-7 w-7" />
                  </div>
                  <CardTitle className="text-xl">{module.title}</CardTitle>
                  <CardDescription>
                    <Badge variant="secondary" className="mt-2">
                      <BookOpen className="mr-1 h-3 w-3" />
                      {module.lessons}
                    </Badge>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{module.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-included-title">
              O Que Está Incluído no EcomFy
            </h2>
            <p className="text-lg text-muted-foreground">
              Tudo que você precisa para começar e escalar seu negócio online
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
            {[
              { icon: BookOpen, title: "150+ Aulas Práticas", description: "Conteúdo direto ao ponto, do zero ao avançado" },
              { icon: Target, title: "50+ Módulos Completos", description: "Organizados em 7 seções para fácil navegação" },
              { icon: Users, title: "Grupos VIP no WhatsApp", description: "Networking com outros alunos e suporte direto" },
              { icon: MessageCircle, title: "Suporte Individual", description: "Acesso direto aos mentores pelo WhatsApp" },
              { icon: Sparkles, title: "Atualizações Constantes", description: "Novos conteúdos semanais sem custo adicional" },
              { icon: Award, title: "Certificado de Conclusão", description: "Reconhecimento oficial do curso EcomFy" },
            ].map((item, index) => (
              <div key={index} className="flex gap-4" data-testid={`item-included-${index}`}>
                <div className="flex-shrink-0">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <item.icon className="h-6 w-6" />
                  </div>
                </div>
                <div>
                  <h3 className="mb-2 text-xl font-semibold">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Exclusive Bonuses */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-purple-600/5">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <Badge className="mb-4" variant="default" data-testid="badge-bonus">
              <Gift className="mr-2 h-4 w-4" />
              Bônus Exclusivos
            </Badge>
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-bonus-title">
              Leve Ainda Mais Para Casa
            </h2>
            <p className="text-lg text-muted-foreground">
              Materiais extras para acelerar seus resultados
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-3 max-w-6xl mx-auto">
            {[
              {
                title: "Lista de Produtos Campeões",
                value: "R$ 197",
                description: "100+ produtos de alta demanda e baixa concorrência prontos para vender",
                icon: Star,
              },
              {
                title: "Lista de Fornecedores",
                value: "R$ 297",
                description: "Mais de 100 fornecedores nacionais e internacionais confiáveis",
                icon: Package,
              },
              {
                title: "Materiais Exclusivos",
                value: "R$ 147",
                description: "PDFs, planilhas, mapas mentais e roteiros de aulas",
                icon: Sparkles,
              },
            ].map((bonus, index) => (
              <Card key={index} className="border-2 border-primary/20 hover-elevate transition-all duration-300" data-testid={`card-bonus-${index}`}>
                <CardHeader>
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground mx-auto">
                    <bonus.icon className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-center text-xl">{bonus.title}</CardTitle>
                  <div className="text-center">
                    <Badge variant="secondary" className="mt-2">
                      Valor: {bonus.value}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">{bonus.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Student Results */}
      <section className="py-20 bg-background" id="resultados">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-results-title">
              Resultados Reais dos Nossos Alunos
            </h2>
            <p className="text-lg text-muted-foreground">
              Não precisa acreditar apenas em nós. Veja o que nossos alunos conquistaram
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-12">
            {[
              {
                name: "Ana Paula",
                result: "R$ 87.000 em 3 meses",
                platform: "Shopee",
                description: "Comecei do zero e hoje tenho minha liberdade financeira",
              },
              {
                name: "Carlos Eduardo",
                result: "R$ 125.000 em 4 meses",
                platform: "Mercado Livre",
                description: "Larguei o emprego CLT e tripliquei minha renda",
              },
              {
                name: "Mariana Costa",
                result: "R$ 56.000 em 2 meses",
                platform: "Amazon",
                description: "Consegui realizar o sonho da casa própria",
              },
              {
                name: "Roberto Silva",
                result: "R$ 98.000 em 3 meses",
                platform: "TikTok Shop",
                description: "Aposentadoria antecipada aos 45 anos",
              },
              {
                name: "Juliana Santos",
                result: "R$ 72.000 em 2 meses",
                platform: "Shopee + ML",
                description: "Construí meu próprio negócio trabalhando de casa",
              },
              {
                name: "Pedro Oliveira",
                result: "R$ 150.000 em 5 meses",
                platform: "Multiplataforma",
                description: "Escala que nunca imaginei ser possível",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="hover-elevate transition-all duration-300" data-testid={`card-testimonial-${index}`}>
                <CardHeader>
                  <div className="flex items-center gap-4 mb-2">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold text-lg">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{testimonial.name}</CardTitle>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {testimonial.platform}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-primary">{testimonial.result}</div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground italic">"{testimonial.description}"</p>
                  <div className="flex gap-1 mt-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto text-center">
            <div className="p-6 rounded-lg bg-primary/5" data-testid="stat-active-students">
              <div className="text-4xl font-bold text-primary mb-2">2.000+</div>
              <div className="text-sm text-muted-foreground">Alunos Ativos</div>
            </div>
            <div className="p-6 rounded-lg bg-primary/5" data-testid="stat-annual-revenue">
              <div className="text-4xl font-bold text-primary mb-2">R$50M+</div>
              <div className="text-sm text-muted-foreground">Faturamento Anual</div>
            </div>
            <div className="p-6 rounded-lg bg-primary/5" data-testid="stat-taxes-paid">
              <div className="text-4xl font-bold text-primary mb-2">R$5M+</div>
              <div className="text-sm text-muted-foreground">Impostos Pagos</div>
            </div>
            <div className="p-6 rounded-lg bg-primary/5" data-testid="stat-jobs-created">
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">Empregos Gerados</div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-purple-600 text-primary-foreground" id="preco">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-yellow-400 text-gray-900 hover:bg-yellow-300" data-testid="badge-urgency">
                <Clock className="mr-2 h-4 w-4" />
                Vagas Limitadas - Últimas Unidades
              </Badge>
              <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-pricing-title">
                Investimento no Seu Futuro
              </h2>
              <p className="text-xl text-primary-foreground/90">
                Tudo que você precisa para transformar sua vida através do e-commerce
              </p>
            </div>

            <Card className="border-0 shadow-2xl bg-white dark:bg-gray-900 max-w-2xl mx-auto">
              <CardHeader className="text-center pb-4">
                <div className="text-center mb-6">
                  <div className="text-lg text-muted-foreground line-through mb-2" data-testid="text-price-original">De R$ 1.997</div>
                  <div className="text-6xl font-bold text-primary mb-2" data-testid="text-price-installment">12x R$ 67,80</div>
                  <div className="text-2xl text-muted-foreground" data-testid="text-price-cash">ou R$ 697 à vista</div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-t border-b py-6 space-y-3">
                  {[
                    "150+ Aulas Práticas e Diretas ao Ponto",
                    "50+ Módulos do Zero ao Avançado",
                    "Suporte VIP Individual no WhatsApp",
                    "Grupos Exclusivos de Alunos",
                    "Lista de Produtos Campeões (R$ 197)",
                    "Lista de Fornecedores (R$ 297)",
                    "Materiais Exclusivos (R$ 147)",
                    "Atualizações Constantes Sem Custo",
                    "Acesso Imediato e Vitalício",
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-3" data-testid={`item-pricing-${index}`}>
                      <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-primary" />
                      <span className="text-foreground">{item}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-3 pt-4">
                  <Button
                    size="lg"
                    onClick={scrollToContact}
                    className="w-full bg-primary text-primary-foreground text-xl py-8 font-bold shadow-xl"
                    data-testid="button-cta-pricing"
                  >
                    <Zap className="mr-2 h-6 w-6" />
                    Garantir Minha Vaga Agora
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={scrollToContact}
                    className="w-full text-lg py-6"
                    data-testid="button-whatsapp-pricing"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Falar com um Consultor
                  </Button>
                </div>

                <div className="text-center pt-4">
                  <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span>Ambiente Seguro</span>
                    <span>•</span>
                    <span>Acesso Imediato</span>
                    <span>•</span>
                    <span>Garantia de 7 Dias</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-background" id="faq">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-faq-title">
              Perguntas Frequentes
            </h2>
            <p className="text-lg text-muted-foreground">
              Tire suas dúvidas sobre o curso EcomFy
            </p>
          </div>

          <div className="mx-auto max-w-3xl">
            <Accordion type="single" collapsible className="space-y-4">
              {[
                {
                  question: "O curso é 100% online?",
                  answer: "Sim! Você pode acessar de qualquer lugar do mundo, a qualquer hora. As aulas ficam disponíveis 24/7 na plataforma.",
                },
                {
                  question: "Preciso ter experiência prévia?",
                  answer: "Não! O EcomFy foi desenvolvido para atender desde iniciantes completos até quem já vende e quer escalar. Começamos do absoluto zero.",
                },
                {
                  question: "Quanto tempo até os primeiros resultados?",
                  answer: "Depende da sua dedicação, mas muitos alunos conseguem as primeiras vendas nas primeiras semanas. Com 1-2 horas por dia, você pode construir um negócio sólido.",
                },
                {
                  question: "Preciso de muito dinheiro para começar?",
                  answer: "Não! É possível começar com investimento a partir de R$ 150 em produtos. Ensinamos estratégias para começar com baixo capital.",
                },
                {
                  question: "Preciso de um computador?",
                  answer: "Não necessariamente! Muitas atividades podem ser feitas pelo celular. Um computador facilita, mas não é obrigatório.",
                },
                {
                  question: "O suporte é realmente individual?",
                  answer: "Sim! Você terá acesso direto à equipe e aos mentores Diogo e Oliveira através de um número exclusivo no WhatsApp.",
                },
                {
                  question: "Tem garantia?",
                  answer: "Sim! Oferecemos 7 dias de garantia incondicional. Se não gostar, devolvemos 100% do seu investimento.",
                },
                {
                  question: "O acesso é vitalício?",
                  answer: "Sim! Uma vez aluno, sempre aluno. Você terá acesso vitalício a todo conteúdo e atualizações futuras sem custo adicional.",
                },
              ].map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border rounded-lg px-6 hover-elevate"
                  data-testid={`accordion-faq-${index}`}
                >
                  <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                        <ChevronDown className="h-4 w-4" />
                      </div>
                      <span>{item.question}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pl-11 pr-4 pb-4">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-20 bg-muted/30" id="contato">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-2xl">
            <div className="text-center mb-12">
              <h2 className="mb-4 font-heading text-4xl font-bold md:text-5xl" data-testid="text-contact-title">
                Ainda Tem Dúvidas?
              </h2>
              <p className="text-lg text-muted-foreground">
                Preencha o formulário e nossa equipe entrará em contato
              </p>
            </div>

            <Card>
              <CardContent className="pt-6">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome Completo</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Digite seu nome"
                              {...field}
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="seu@email.com"
                              {...field}
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>WhatsApp</FormLabel>
                          <FormControl>
                            <Input
                              type="tel"
                              placeholder="(00) 00000-0000"
                              {...field}
                              data-testid="input-phone"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mensagem (Opcional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Digite sua dúvida ou mensagem"
                              className="resize-none"
                              rows={4}
                              {...field}
                              data-testid="input-message"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full"
                      disabled={createContactMutation.isPending}
                      data-testid="button-submit-contact"
                    >
                      {createContactMutation.isPending ? (
                        "Enviando..."
                      ) : (
                        <>
                          <MessageCircle className="mr-2 h-5 w-5" />
                          Enviar Mensagem
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-3 mb-8">
            <div>
              <h3 className="text-2xl font-heading font-bold text-white mb-4">EcomFy</h3>
              <p className="text-gray-400 mb-4">
                O curso completo de e-commerce que vai transformar sua vida financeira através das vendas online.
              </p>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-800 hover-elevate transition-colors"
                  aria-label="Instagram"
                  data-testid="link-instagram"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="#"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-800 hover-elevate transition-colors"
                  aria-label="YouTube"
                  data-testid="link-youtube"
                >
                  <Youtube className="h-5 w-5" />
                </a>
                <a
                  href="#"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-800 hover-elevate transition-colors"
                  aria-label="Facebook"
                  data-testid="link-facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Links Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#plataformas" className="hover:text-primary transition-colors" data-testid="link-plataformas">
                    Plataformas
                  </a>
                </li>
                <li>
                  <a href="#mentores" className="hover:text-primary transition-colors" data-testid="link-mentores">
                    Mentores
                  </a>
                </li>
                <li>
                  <a href="#modulos" className="hover:text-primary transition-colors" data-testid="link-modulos">
                    Módulos
                  </a>
                </li>
                <li>
                  <a href="#resultados" className="hover:text-primary transition-colors" data-testid="link-resultados">
                    Resultados
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-primary transition-colors" data-testid="link-faq">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Contato</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#contato" className="hover:text-primary transition-colors" data-testid="link-contato">
                    Formulário de Contato
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors" data-testid="link-whatsapp">
                    WhatsApp
                  </a>
                </li>
                <li className="text-gray-400" data-testid="text-support-hours">
                  Suporte disponível de segunda a sexta, das 9h às 18h
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8">
            <p className="text-center text-sm text-gray-500 mb-4">
              Este site não faz parte do Facebook, Meta ou qualquer empresa relacionada. Além disso, NÃO é endossado pelo Facebook de forma alguma.
            </p>
            <p className="text-center text-sm text-gray-500 mb-4">
              O EcomFy compartilha estratégias e conhecimentos para ajudar empreendedores a construir negócios sustentáveis no e-commerce.
              Os resultados podem variar de acordo com dedicação, investimento e outros fatores individuais. Não garantimos resultados específicos.
            </p>
            <p className="text-center text-gray-400">
              Copyright © {new Date().getFullYear()} EcomFy. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
